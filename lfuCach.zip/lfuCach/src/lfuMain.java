public class lfuMain {

    public static void   main(String args[])
    {
        lfuCache cache = new lfuCache(2);
        cache.put(1,"first value");
        cache.put(2,"2");
        cache.get(1);
        cache.put(3,"third value added");
        cache.get(2);
    }
}
