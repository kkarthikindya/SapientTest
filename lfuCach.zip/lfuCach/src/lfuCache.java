import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class lfuCache {
    class Node
    {
        int key;
        String value;
        int count;
        Node next,prev;

        public Node(int key, String value, int count) {
            this.key = key;
            this.value = value;
            this.count = count;
        }
    }
 int freqMin, capacity;
    Map<Integer, Node> map;
    Map<Integer,List<Node>> freqMap;
    Map<Integer,Integer> freqPosMap;

    public lfuCache(int capacity)
    {
        this.capacity=capacity;
        this.freqMin=0;
        this.map= new HashMap<>();
        this.freqMap = new HashMap<>();
        this.freqPosMap = new HashMap<>();
    }

    public int get(int key)
    {
        System.out.println("Geting key now for the cache:" + key);
        if(!map.containsKey(key))
        {
            return -1;
        }
        Node node = map.get(key);
       freqMap.get(node.count).remove((int)(freqPosMap.get(key)));
       node.count += 1;
       if(!freqMap.containsKey(node.count))
       {
           freqMap.put(node.count,new ArrayList<>());
       }
       freqMap.get(node.count).add(node);

       freqPosMap.put(key,freqMap.get(node.count).size()-1);

       if(freqMap.get(freqMin).size() == 0) freqMin++;

        System.out.println("After getting key:" +key);
        printmap();
        return node.key;


    }


    public void put(int key, String value)
    {
        System.out.println("Starting to get the Key " +key + "value" + value);
        if(capacity <0)
        {
            return;
        }
        if(map.containsKey(key))
        {
            map.get(key).value=value;
            return;
        }

        if(map.size() >= capacity)
        {
            Node node = freqMap.get(freqMin).get(0);
            map.remove(node.key);
            freqMap.get(freqMin).remove(0);
            freqPosMap.remove(node.key);
        }

        Node newNode = new Node(key,value,1);
        map.put(key, newNode);
        if(!freqMap.containsKey(newNode.count)){
            freqMap.put(newNode.count, new ArrayList<>());
        }
        freqMap.get(newNode.count).add(newNode);
        freqPosMap.put(key, freqMap.get(newNode.count).size()-1);
        freqMin = 1;
        System.out.println("After puting key " +key+ "value" + value);
        printmap();
    }
    private void printmap() {
        System.out.println("Printng Map");
        for(Node node:map.values())
        {
            System.out.println("Key:" + node.key + "value"+ node.value );
        }
        System.out.println("frequent Map");
        for(Map.Entry<Integer,List<Node>> entry: freqMap.entrySet() )
        {
            System.out.println(entry.getKey() + "Size of the list -- > " + entry.getValue().size());
        }
        System.out.println("Frequency Position");
        for(Map.Entry<Integer, Integer> entry: freqPosMap.entrySet()){
            System.out.println("key:" + entry.getKey() + "Pos Map value" + entry.getValue());
        }
        System.out.println("Min frequency List");
        for(Node node : freqMap.get(freqMin)){
            System.out.println(node.key + "->");
        }
    }
}
