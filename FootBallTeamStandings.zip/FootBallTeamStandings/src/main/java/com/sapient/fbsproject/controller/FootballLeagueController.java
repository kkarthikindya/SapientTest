package com.sapient.fbsproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sapient.fbsproject.model.FootBallStandingResponseModel;
import com.sapient.fbsproject.service.FootballLeagueService;

@SpringBootApplication
@EnableEurekaServer
@RestController
@RequestMapping("/football")
public class FootballLeagueController {

	@Autowired
	FootballLeagueService service;

	@RequestMapping(method = RequestMethod.GET, path = "/getStandings", produces = "application/JSON")
	public FootBallStandingResponseModel getStandingDetails(@RequestParam String countryName,
			@RequestParam String leagueName, @RequestParam String teamName) {
		FootBallStandingResponseModel response = new FootBallStandingResponseModel();
		response = service.getStandings(countryName, leagueName, teamName);

		return response;
	}

}
