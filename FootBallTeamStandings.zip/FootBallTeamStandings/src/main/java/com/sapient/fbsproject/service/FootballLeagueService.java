package com.sapient.fbsproject.service;

import com.sapient.fbsproject.model.FootBallStandingResponseModel;

public interface FootballLeagueService {
	public FootBallStandingResponseModel getStandings(String countryName, String leagueName, String teamName);
}
