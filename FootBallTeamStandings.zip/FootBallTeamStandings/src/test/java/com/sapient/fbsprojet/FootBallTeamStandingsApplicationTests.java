package com.sapient.fbsprojet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootBallTeamStandingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
